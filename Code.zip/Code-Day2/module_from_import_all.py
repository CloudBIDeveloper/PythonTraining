#import all name

from my_maths import *

print(sub(4,5))


