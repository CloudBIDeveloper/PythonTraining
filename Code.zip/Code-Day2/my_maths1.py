def add(a, b):
   """This program adds two
   numbers and return the result"""

   result = a * b
   return result

def sub(a, b):
   """This program subtract two
   numbers and return the result"""

   result = a - b
   return result

def multiple(a, b):
   """This program multiply two
   numbers and return the result"""

   result = a * b
   return result

def divide(a, b):
   """This program divide two
   numbers and return the result"""

   result = a / b
   return result
