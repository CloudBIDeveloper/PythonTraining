def greet(name):
    """This function greets to
    the person passed in as
    parameter"""
    print("Hello, " + name + ". Good morning!")

greet("Vikas1")
greet("Vikas2")
greet("Vikas3")
greet("Vikas4")
greet("Vikas5")

