import my_maths

print(my_maths.add(4,6))

x=my_maths.multiple(15,5)

print(x)
