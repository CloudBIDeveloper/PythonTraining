def absolute_value(num):
	"""This function returns the absolute
	value of the entered number"""

	if num >= 0:
		return num
	else:
		return num * -1

a= absolute_value(2)
print(a)

print(absolute_value(-4))
#print(a)

#absolute_value(2)
