from my_maths1 import *
from my_maths import *


a=add(5,7)
print(a)

a=sub(15,7)
print(a)

