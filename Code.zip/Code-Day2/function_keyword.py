def greet(name,msg):
   """This function greets to
   the person with the provided message"""
   print("Hello",name + ', ' + msg)

greet("Monica","Good morning!")

# 2 keyword arguments
greet(name = "Bruce",msg = "How do you do?")

# 2 keyword arguments (out of order)
greet(msg = "How do you do?",name = "Bruce")

# 1 positional, 1 keyword argument
greet("Bruce",msg = "How do you do?")

#keyword arguments must follow positional arguments.
#SyntaxError: non-keyword arg after keyword arg
#greet(name="Bruce","How do you do?")
