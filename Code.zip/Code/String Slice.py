str = 'programiz'
print('str = ', str)

#first character
print('str[0] = ', str[0])

#last character
print('str[-1] = ', str[-3])

#slicing 2nd to 5th character
print('str[1:5] = ', str[1:5])

