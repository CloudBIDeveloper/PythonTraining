d = {1:'Bax','NM':'Baxter',12:'Dec','May':5}

print(type(d))

print("d[1] = ", d[1]);

print("d['NM'] = ", d['NM']);

print("d[12] = ", d[12]);

# Generates error
#print("d[5] = ", d[5]);

print("d['May'] = ", d['May']);
