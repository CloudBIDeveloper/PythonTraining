str='ALSKJXKLSAXAXKLAXMALK'

print(str)

new_str=str.replace('A','P')

print(new_str)
