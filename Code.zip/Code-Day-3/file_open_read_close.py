#File I/O Example

try:
    #Open file
    f = open("LICENSE.txt",'r')
    print("file open")

    #Read 20 Characters
    print(f.read(20))
    print(f.tell())
    print(f.seek(0))

    #Read entire file
    #print(f.read())
   
finally:
    #Close the file
    print("file close")
    f.close()

  
