#File read line by line

try:
    #Open file
    f = open("LICENSE.txt",'r')
    print("file open")

    #for line in f:
    #    print(line)

    #print(f.readlines())
    print(f.readlines())
    
   
finally:
    #Close the file
    print("file close")
    f.close()

  
