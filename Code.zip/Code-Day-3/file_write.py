#File write, End by ZZ
try:
    #Open file
    f = open("demo.txt",'w')
    print("file open")

    while True:
        x=input()
        if x=='ZZ':
            break
        #f.write(x + '\n')
        f.writelines(x + '\n')
       
finally:
    #Close the file
    print("file close")
    f.close()

  
