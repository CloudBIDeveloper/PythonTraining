listOfStudents=['Mohan','John','Ramesh','Mohan','John']
print("List of Students:",listOfStudents)
uniqueNames=set(listOfStudents)
print("Set of uniqueNames:",uniqueNames)

listOfMarks=[8,7,6,7,8,8,7,6,7,8,9]
print("List of Makrs:",listOfMarks)
setOfMarks=set(listOfMarks)
print("Set of marks:",setOfMarks)

newSet={2,9,10}

print("Minus",setOfMarks - newSet)

ListSet=list(newSet)

print("ListSet",ListSet)
